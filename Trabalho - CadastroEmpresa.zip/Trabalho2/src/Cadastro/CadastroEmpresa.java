package Cadastro;

import java.util.ArrayList;
import java.util.Scanner;

public class CadastroEmpresa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Empresa> empresas = new ArrayList<>();
        
        // Cadastro de empresas
        while (true) {
            System.out.println("\n--- Cadastro de Empresa ---");
            System.out.print("Digite o nome da empresa (ou 0 para sair): ");
            String nome = scanner.nextLine();
            if (nome.equals("0")) break;
            
            System.out.print("Digite o CNPJ da empresa: ");
            String cnpj = scanner.nextLine();
            
            System.out.print("Digite a renda bruta mensal da empresa: ");
            double rendaBrutaMensal = scanner.nextDouble();
            scanner.nextLine(); // Limpar o buffer do scanner
            
            // Criar e adicionar empresa à lista
            Empresa empresa = new Empresa(nome, cnpj, rendaBrutaMensal);
            empresas.add(empresa);
            
            System.out.println("Empresa cadastrada com sucesso!");
        }
        
        // Exibir empresas cadastradas
        System.out.println("\n--- Empresas Cadastradas ---");
        for (Empresa empresa : empresas) {
            System.out.println("\nNome: " + empresa.getNome());
            System.out.println("CNPJ: " + empresa.getCnpj());
            System.out.println("Renda Bruta Mensal: " + empresa.getRendaBrutaMensal());
        }
        
        scanner.close();
    }
}

class Empresa {
    private String nome;
    private String cnpj;
    private double rendaBrutaMensal;
    
    // Construtor
    public Empresa(String nome, String cnpj, double rendaBrutaMensal) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.rendaBrutaMensal = rendaBrutaMensal;
    }
    
    // Getters
    public String getNome() {
        return nome;
    }
    
    public String getCnpj() {
        return cnpj;
    }
    
    public double getRendaBrutaMensal() {
        return rendaBrutaMensal;
    }
}