package application;

import entities.Graduacao_Vinicius_Pereira_Marques;
import entities.PosGraduacao_Vinicius_Pereira_Marques;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Programa_Vinicius_Pereira_Marques {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Graduacao_Vinicius_Pereira_Marques> graduacoes = new ArrayList<>();
        List<PosGraduacao_Vinicius_Pereira_Marques> posGraduacoes = new ArrayList<>();

        while (true) {
            System.out.println("MENU:");
            System.out.println("1 – Cadastro Graduação");
            System.out.println("2 – Cadastro Pós-Graduação");
            System.out.println("3 – Sair");
            int opcao = scanner.nextInt();
            scanner.nextLine();  // Consumir a quebra de linha

            if (opcao == 1) {
                if (graduacoes.size() < 10) {
                    Graduacao_Vinicius_Pereira_Marques graduacao = new Graduacao_Vinicius_Pereira_Marques();
                    System.out.println("Digite o nome:");
                    graduacao.setNome(scanner.nextLine());
                    System.out.println("Digite o CPF:");
                    graduacao.setCpf(scanner.nextLine());
                    System.out.println("Digite a matrícula:");
                    graduacao.setMatricula(scanner.nextLine());
                    System.out.println("Digite o curso de graduação:");
                    graduacao.setCursoGraduacao(scanner.nextLine());
                    graduacoes.add(graduacao);
                } else {
                    System.out.println("Número máximo de cadastros de graduação atingido.");
                }
            } else if (opcao == 2) {
                if (posGraduacoes.size() < 10) {
                    PosGraduacao_Vinicius_Pereira_Marques posGraduacao = new PosGraduacao_Vinicius_Pereira_Marques();
                    System.out.println("Digite o nome:");
                    posGraduacao.setNome(scanner.nextLine());
                    System.out.println("Digite o CPF:");
                    posGraduacao.setCpf(scanner.nextLine());
                    System.out.println("Digite a matrícula:");
                    posGraduacao.setMatricula(scanner.nextLine());
                    System.out.println("Digite o curso de pós-graduação:");
                    posGraduacao.setCursoPosgraduacao(scanner.nextLine());
                    posGraduacoes.add(posGraduacao);
                } else {
                    System.out.println("Número máximo de cadastros de pós-graduação atingido.");
                }
            } else if (opcao == 3) {
                break;
            } else {
                System.out.println("Opção inválida.");
            }
        }

        System.out.println("Cadastros de Graduação:");
        for (Graduacao_Vinicius_Pereira_Marques g : graduacoes) {
            System.out.println(g);
        }

        System.out.println("Cadastros de Pós-Graduação:");
        for (PosGraduacao_Vinicius_Pereira_Marques p : posGraduacoes) {
            System.out.println(p);
        }

        scanner.close();
    }
}