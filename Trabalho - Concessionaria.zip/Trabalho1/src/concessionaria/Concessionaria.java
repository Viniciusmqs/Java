package concessionaria;

import java.util.Scanner;

public class Concessionaria {
    private static final String SENHA_CORRETA = "123";
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("--- Bem-vindo à Concessionária ---");
        System.out.print("Digite a senha: ");
        String senha = scanner.nextLine();

        if (senha.equals(SENHA_CORRETA)) {
            System.out.println("SENHA CORRETA\n");

            while (true) {
                exibirMenu();
                int opcao = scanner.nextInt();
                scanner.nextLine(); // Limpa o buffer do scanner

                switch (opcao) {
                    case 1:
                        cadastrarCliente();
                        break;
                    case 2:
                        comprarCarro();
                        break;
                    case 3:
                        comprarAcessorio();
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                        break;
                }
            }
        } else {
            System.out.println("ERRO DE SENHA. Tente novamente.");
        }

        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("\n--- Menu ---");
        System.out.println("1. Cadastro de Cliente");
        System.out.println("2. Compra de Carro");
        System.out.println("3. Compra de Acessório");
        System.out.println("Escolha uma opção (1, 2 ou 3): ");
    }

    private static void cadastrarCliente() {
        System.out.println("\n--- Cadastro de Cliente ---");
        System.out.print("Digite o nome do cliente: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o telefone do cliente: ");
        String telefone = scanner.nextLine();
        System.out.print("Digite o endereço do cliente: ");
        String endereco = scanner.nextLine();
        System.out.println("Cliente cadastrado com sucesso!");
    }

    private static void comprarCarro() {
        System.out.println("\n--- Compra de Carro ---");
        System.out.println("Escolha uma opção de carro:");
        System.out.println("1. Carro A");
        System.out.println("2. Carro B");
        System.out.println("3. Carro C");
        System.out.print("Escolha o carro (1, 2 ou 3): ");
        int escolhaCarro = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer do scanner

        String carro;
        switch (escolhaCarro) {
            case 1:
                carro = "Carro A";
                break;
            case 2:
                carro = "Carro B";
                break;
            case 3:
                carro = "Carro C";
                break;
            default:
                System.out.println("Opção inválida.");
                return;
        }

        System.out.println("Escolha uma cor:");
        System.out.println("1. Vermelho");
        System.out.println("2. Azul");
        System.out.println("3. Preto");
        System.out.print("Escolha a cor (1, 2 ou 3): ");
        int escolhaCor = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer do scanner

        String cor;
        switch (escolhaCor) {
            case 1:
                cor = "Vermelho";
                break;
            case 2:
                cor = "Azul";
                break;
            case 3:
                cor = "Preto";
                break;
            default:
                System.out.println("Opção inválida.");
                return;
        }

        System.out.println("Escolha uma forma de pagamento:");
        System.out.println("1. À vista");
        System.out.println("2. Financiamento");
        System.out.println("3. Leasing");
        System.out.print("Escolha a forma de pagamento (1, 2 ou 3): ");
        int escolhaPagamento = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer do scanner

        String formaPagamento;
        switch (escolhaPagamento) {
            case 1:
                formaPagamento = "À vista";
                break;
            case 2:
                formaPagamento = "Financiamento";
                break;
            case 3:
                formaPagamento = "Leasing";
                break;
            default:
                System.out.println("Opção inválida.");
                return;
        }

        System.out.println("Compra do carro " + carro + " (" + cor + ") realizada com sucesso!");
        System.out.println("Forma de pagamento: " + formaPagamento);
    }

    private static void comprarAcessorio() {
        System.out.println("\n--- Compra de Acessório ---");
        System.out.print("Digite o nome do acessório: ");
        String nomeAcessorio = scanner.nextLine();
        System.out.print("Digite a quantidade desejada: ");
        int quantidade = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer do scanner
        System.out.println("Compra do acessório " + nomeAcessorio + " realizada com sucesso!");
    }
}