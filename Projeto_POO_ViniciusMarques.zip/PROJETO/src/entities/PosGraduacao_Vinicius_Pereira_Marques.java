package entities;

public class PosGraduacao_Vinicius_Pereira_Marques extends Pessoas {
    private String cursoPosgraduacao;

    // Getters e Setters
    public String getCursoPosgraduacao() {
        return cursoPosgraduacao;
    }

    public void setCursoPosgraduacao(String cursoPosgraduacao) {
        this.cursoPosgraduacao = cursoPosgraduacao;
    }

    @Override
    public String toString() {
        return "PosGraduacao_Vinicius_Pereira_Marques{" +
                "nome='" + getNome() + '\'' +
                ", cpf='" + getCpf() + '\'' +
                ", matricula='" + getMatricula() + '\'' +
                ", cursoPosgraduacao='" + cursoPosgraduacao + '\'' +
                '}';
    }
}