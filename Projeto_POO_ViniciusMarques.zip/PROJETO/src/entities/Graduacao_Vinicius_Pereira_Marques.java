package entities;

public class Graduacao_Vinicius_Pereira_Marques extends Pessoas {
    private String cursoGraduacao;

    // Getters e Setters
    public String getCursoGraduacao() {
        return cursoGraduacao;
    }

    public void setCursoGraduacao(String cursoGraduacao) {
        this.cursoGraduacao = cursoGraduacao;
    }

    @Override
    public String toString() {
        return "Graduacao_Vinicius_Pereira_Marques{" +
                "nome='" + getNome() + '\'' +
                ", cpf='" + getCpf() + '\'' +
                ", matricula='" + getMatricula() + '\'' +
                ", cursoGraduacao='" + cursoGraduacao + '\'' +
                '}';
    }
}